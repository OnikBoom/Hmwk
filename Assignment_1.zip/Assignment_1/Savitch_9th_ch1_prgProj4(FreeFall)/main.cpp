/* 
 * File:   main.cpp
 * Author: Imtiaz Hossain
 * Created on February 23, 2016, 11:06 AM
 */
//System Libraries
#include <iostream>
using namespace std;
//User Libraries
//Global Constants
const float G = 9.8;
//Main function
int main() {
    //Declare variables
    float dist, time;
    //Welcome user / instructions for user
    cout << "Hello," << endl;
    cout << "This program allows you to calculate the approximate distance " << endl;
    cout << "an object would travel, in freefall, for a given amount of time." << endl;
    cout << "Please type in the desired freefall time in (seconds): " << endl;
     //Prompt user input   
        cin >> time;
    //Calculation G = acceleration of gravity, dist = (9.8 m/s^2) / 2
    dist = ((G) * (time * time)) / 2;
    //Output    
    cout << "If an object were to free fall for " << time << " seconds,"<< endl;
    cout << "It would have traveled an approximate distance of: " << endl;
    cout << dist << " meters" << endl;
    cout << "Thank you." << endl;
    
    //Exit Stage right ~~
    return 0;
}

