/* 
 * File:   main.cpp
 * Author: Imtiaz Hossain
 * CSC 5 42829 
 * Created on February 23, 2016, 8:48 AM
 */

//System Libraries
#include <iostream>
using namespace std;
//User Libraries
//Global Constants
//Main Function
int main ()
{
    //Declare variables
    int numPods, numPeas, totPeas;
    string retry;
    
    cout << "Press return after entering a number" << endl;
    cout << "Enter the number of pods: ";
    //Prompt user input
    cin >> numPods;
    
    cout << "Enter the number of peas in a pod: ";
    //Prompt user input
    cin >> numPeas;
    //Calculation
    totPeas = numPods * numPeas;
    //Output
    cout << "If you have " << numPods << " pea pods " << endl
         << "and " << numPeas << " peas in each pod," << endl   
         << "You have " << totPeas << " peas in all the pods." << endl << endl
         << "Would you like to try again?" << endl
         << "If so, type \"yes\" otherwise, type any key" << endl
         << "and hit enter to end the program." << endl;
    //Prompt retry / repeat loop or terminate
    cin >> retry;
     if (retry != "yes")
        {
            cout << "Thank you! Good Bye." << endl; 
        }
    
    while (retry == "yes")
    {        
    cout << "Enter the number of pods: ";
        cin >> numPods;
    
    cout << "Enter the number of peas in a pod: ";
        cin >> numPeas;
    
    totPeas = numPods * numPeas;
    
    cout << "If you have " << numPods << " pea pods " << endl
         << "and " << numPeas << " peas in each pod," << endl   
         << "You have " << totPeas << " peas in all the pods." << endl << endl
         << "Would you like to try again?" << endl
         << "If so, type \"yes\" and return" << endl
         << "otherwise type any key and hit enter to end the program " << endl;
        cin >> retry;
    }
    //Exit stage right ~~       
    return 0;
    
    }