/* 
 * File:   main.cpp
 * Author: Imtiaz Hosain
 * CSC 5 42829
 * Created on March 2, 2016, 9:29 AM
 */

 /* Sources :
     * https://www.nationalpriorities.org/budget-basics/federal-budget-101/
     * spending/
     * https://en.wikipedia.org/wiki/Military_budget_of_the_United_States
     * https://en.wikipedia.org/wiki/Budget_of_NASA */
    
//System Libraries    
#include <iostream>
using namespace std;
//User Libraries
//Global Functions
//Main function
int main() {
    //Declare variables
    float mltry, nasa, totFed = 3.8e12f;
    //Coversion / Calculation
    mltry = (5.81e11f / totFed) * 100;    
    nasa = (1.84e10 / totFed) * 100;
    
    //Output
    cout << "With a total federal budget of " << totFed << " total" << endl
         << "military budget is " << mltry << "%"
         << "of total federal budget." << endl
         << "Total NASA budget is " << nasa << "%"
         << "of total federal budget.";    
   
    return 0;
}