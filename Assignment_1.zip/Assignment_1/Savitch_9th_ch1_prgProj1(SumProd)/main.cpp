/* 
 * File:   main.cpp
 * Author: Imtiaz Hossain
 *
 * Created on February 23, 2016, 9:25 AM
 */
//System Libraries
#include <iostream>
using namespace std;
//User libraries
//Global constants

//Main function
int main() {
    //Declare variables
    int a, b, sum, prod;
    //Welcome user to program
    cout << "Hello." << endl;
    cout << "Please input values for A and B to " << endl;
    cout << "calculate their sum and product:" << endl;
    cout << " A =  ";
    //Prompt user input
    cin >> a;
    cout << " B =  ";
    cin >> b;
    //Calculation
    sum = a + b;
    prod = a * b;
    //Output        
    cout << "The sum of A and B is: ";
    cout << sum << endl;
    cout << "The product of A and B is: ";
    cout << prod << endl;
    
    cout << "Thank You." << endl;
    cout << "Goodbye." << endl;
   
    //Exit stage right ~~
    return 0;
}

