/* 
 * File:   main.cpp
 * Author: Imtiaz Hossain
 * CSC 5 42829
 * Created on February 27, 2016, 7:43 PM
 */

// System Libraries
#include <iostream>

using namespace std;

// User Libraries
// Global Constants

// Main Function
int main ()
{
    //Declare Variables
    int count (1);
    float r, n, guess;
    
    cout << "Enter the number for which you'd like the square root:" << endl;
    //Prompt for input
    cin >> n;
    
    cout << "Enter what you think the square root is: " << endl;
    
    cin >> guess;
    
        while (count <= 100)
    {
        //Calculation / loop
        r = n / guess;
        guess = (guess + r) / 2; 
        count++;
        cout << r << endl;        
    }
    //Output
    cout << "The square root of " << n << " is " << r << endl;
    cout << "Thank you!" << endl;
    
    //Exit stage right ~~
    return 0;
}