/* 
 * File:   main.cpp
 * Author: Imtiaz Hossain
 * CSC 5 42829
 * Created on February 23, 2016, 1:07 PM
 */
//System Libraries
#include <iostream>
using namespace std;
//User Libraries
//Global Constants
//Main function
int main() {
    //Declare variables
    unsigned char x; 
    cout << "Hello there!" << endl
         << "In this program, we will create an image of " << endl
         << "the letter C composed of character of any value." << endl
         << "Enter the character you'd like to create C with: ";
    //Prompt user input
    cin >> x;
    //Output pattern
    cout <<" "<< x << " " << x << " " << x << endl;
    cout << x << "    " << x << endl;
    cout << x << endl;
    cout << x << "    " << x << endl;
    cout <<" " << x << " " << x << " " << x << endl;
    //Exit stage right ~~
    return 0;
}

