/* 
 * File:   main.cpp
 * Author: Imtiaz Hossain
 * Created on February 23, 2016, 10:41 AM
 */
//System Libraries
#include <iostream>
using namespace std;
//Uswer Libraries
//Global Constants
unsigned char QRTR = 25;
unsigned char DIME = 10;
unsigned char NIKL = 5;
//Main function
int main() {
    //Declare variables
    int qrtrs, dimes, nickls, penny, cents, totCoin;
    //Welcome user / instructions
    cout << "Hello," << endl;
    cout << "Please enter the amount of each type " << endl;
    cout << "of coins you have below: " << endl;
    cout << "Quarters: ";
    //Prompt input
        cin >> qrtrs;    
    cout << "Dimes: ";
        cin >> dimes;        
    cout << "Nickels: "; 
        cin >> nickls;        
    cout << "Pennies: ";
        cin >> penny;
//Calculation of coins        
totCoin = (qrtrs * QRTR) + (dimes * DIME) + (nickls * NIKL) + penny;
cents = totCoin % 100;
//Output
    cout << "Your coins are worth a total of "
         << totCoin << " cents." << endl
         << "Or " << totCoin / 100 << " dollars " // conversion to dollars
         << "and " << cents << " cents." << endl //remaining cents
         << "Thank you." << endl
         << "Bonvoyage~~" << endl;
    //Exit stage right ~~
    return 0;
}

