/* 
 * File:   main.cpp
 * Author: Imtiaz Hosain
 * CSC 5 42829
 * Created on March 2, 2016, 9:29 AM
 */

//System Libraries
#include <iostream>
using namespace std;
//User Libraries
//Global Constants
const float IRSHTAX = 12.5;//12.5% tax rate
const float USATAX = 40.0;//40% tax rate
const float GGLREV = 50e9;//50 billion dollars
//Main Funciton
int main()
{
 //Declare variables
 int ggltax1, ggltax2, ggldif;// hand't finished this one the calculation 
 ggltax1 = USATAX * GGLREV * 01;//was wrong?
 ggltax2 = IRSHTAX * GGLREV * 01;
 ggldif = ggltax1 - ggltax2;
 //Output   
 cout    << "If Google made $50 billion dollars in 2012" << endl
         << "with a USA corporate tax rate of 40%, they" << endl
         << "would be paying " << ggltax1 << " dollars." << endl
         << "However in with a tax rate of 12.5% in Ireland" << endl
         << "They would be paying " << ggltax2 << " dollars." << endl
         << "This would save them a total of " << ggldif << " dollars" << endl
         << "Thank You Good Bye";

    return 0;
}
 