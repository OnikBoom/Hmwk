/* 
 * File:   main.cpp
 * Author: Imtiaz Hossain
 * CSC 5 42829 
 * Created on February 23, 2016, 9:44 AM
 */

//System Libraries
#include <iostream> 
using namespace std;
//User Libraries
//Global Constants

//Main function
int main() {
    //Declare variables
    string cs;
    cout << "Hello," << endl
         << "Did you know that computer science is becoming" << endl
         << "increasingly hip these days? For instance, I've" << endl
         << "devised a program that prints a hidden message" << endl
         << "if you type in the password \"cs1337\"" << endl << endl
         << "Enter the password: ";
   //Prompt input
    cin >> cs;
    //While loop / verify password
    while (cs != "cs1337")
     {
         cout << "That is not the password... try again!" << endl;
         cin >> cs;
     }
     //Output / pattern     
     if (cs == "cs1337") {
        cout << "*************************************************" << endl
             << "        C C C                    S S S S      !! " << endl
             << "      C       C                S         S    !! " << endl
             << "     C                        S               !! " << endl
             << "    C                          S              !! " << endl
             << "    C              Q('-'Q)      S S S S       !! " << endl
             << "     C                                   S    !! " << endl
             << "      C      C                  S         S   !! " << endl
             << "       C C C                      S S S S     @@ " << endl
             << "*************************************************" << endl
             << "        Computer Science is for the 1337         " << endl;
    }
    
    //Exit stage right ~~
    return 0;
}

