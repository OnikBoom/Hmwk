/* 
 * File:   main.cpp
 * Author: Imtiaz Hossain
 * CSC 5 42829 
 * Created on February 27, 2016, 7:43 PM
 */

//System Libraries
#include <iostream>
using namespace std;
//User Libraries
//Global Constants
const float OZMTON = 35273.92;

//Main function
int main ()
{
    //Declare variables   
    float cerBox, cermTon, convrt;
    int counter = 0;
//Welcome user to program
cout << "Hello," << endl << "This program will tell you:" << endl
     << "1. The weight of your cereal box in metric tons." << endl
     << "2. The number of cereal boxes required to fill 1 metric ton." << endl
     << "Please enter the weight of your cereal box: " << endl;

//Repeat program loop
while (counter < 100)
{
//Prompt user input  
cin >> cerBox;
// Conversion formula for ounces --> metric tons
convrt = (cerBox/OZMTON);  
// Number calculation of required cereal boxes to occupy 1 metric ton 
cermTon = (OZMTON/cerBox);
//Output
cout << "Your cereal box is approximately " << convrt << 
        " metric tons!" << endl;
cout << "If each cereal box weighs " << cerBox << " ounces" << endl
     << "You would need " << cermTon << " cereal boxes" << endl
     << "to fill one metric ton!" << endl;
cout << "Enter a different cereal box weight: " << endl;
counter++;
}

//Exit stage right~~
return 0;

}