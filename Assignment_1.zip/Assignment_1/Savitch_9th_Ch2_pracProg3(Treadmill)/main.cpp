/* 
 * File:   main.cpp
 * Author: Imtiaz Hossain
 * CSC 5 42829 
 * Created on February 28, 2016, 10:46 PM
 */
//System Libraries
#include <iostream>
using namespace std;
//User Libraries
//Global Constants
unsigned char MINPHR = 60;//Conversion minutes per hour.
unsigned char SECPMIN = 60;//Conversion seconds per min.
//Main Function
int main()
{
    //Declare variables
    int imin, isec;
    float mph, fmin, fsec;
    
    cout << "Enter a running speed in mph: " << endl;
    //Prompt user input in mph
    cin >> mph;
    //Conversion / calcualtion
    fmin = MINPHR / mph;
    imin = static_cast<int>(fmin);
    fsec = (fmin - imin) * SECPMIN;
    isec = static_cast<int>(fsec);
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    //Output
    cout << "If you are running at " << mph << "mph" << endl
         << "Then you will run a mile in " << endl
         << imin << " minutes and " << fsec << "seconds" << endl;
   
    //Exit stage right~~
    return 0;
}